<?php
/* Smarty version 4.5.5, created on 2025-08-07 08:28:47
  from 'C:\xampp\htdocs\qloapps\admin\themes\default\template\controllers\orders\_filter_hotel_rooms.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_6894479fc5baf4_37444751',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '00828f88823369a6a149b6674d100e2d2483f3af' => 
    array (
      0 => 'C:\\xampp\\htdocs\\qloapps\\admin\\themes\\default\\template\\controllers\\orders\\_filter_hotel_rooms.tpl',
      1 => 1751621738,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6894479fc5baf4_37444751 (Smarty_Internal_Template $_smarty_tpl) {
if (is_array($_smarty_tpl->tpl_vars['hotel_rooms_info']->value) && count($_smarty_tpl->tpl_vars['hotel_rooms_info']->value)) {?>
    <option value="" selected="selected">-</option>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['hotel_rooms_info']->value, 'hotel_room');
$_smarty_tpl->tpl_vars['hotel_room']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['hotel_room']->value) {
$_smarty_tpl->tpl_vars['hotel_room']->do_else = false;
?>
        <option value="<?php echo $_smarty_tpl->tpl_vars['hotel_room']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['hotel_room']->value['room_num'];?>
, <?php echo $_smarty_tpl->tpl_vars['hotel_room']->value['room_type_name'];?>
, <?php echo $_smarty_tpl->tpl_vars['hotel_room']->value['hotel_name'];?>
</option>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
}
}
}
