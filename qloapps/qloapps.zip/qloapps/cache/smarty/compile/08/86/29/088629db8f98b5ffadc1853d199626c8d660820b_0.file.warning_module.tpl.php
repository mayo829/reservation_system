<?php
/* Smarty version 4.5.5, created on 2025-08-07 08:28:47
  from 'C:\xampp\htdocs\qloapps\admin\themes\default\template\controllers\modules\warning_module.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_6894479f6d0009_02654991',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '088629db8f98b5ffadc1853d199626c8d660820b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\qloapps\\admin\\themes\\default\\template\\controllers\\modules\\warning_module.tpl',
      1 => 1751621738,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6894479f6d0009_02654991 (Smarty_Internal_Template $_smarty_tpl) {
?><a href="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['module_link']->value, ENT_QUOTES, 'UTF-8', true);?>
"><?php echo $_smarty_tpl->tpl_vars['text']->value;?>
</a><?php }
}
