<?php
/* Smarty version 4.5.5, created on 2025-08-08 06:09:51
  from 'C:\xampp\htdocs\qloapps\admin1\themes\default\template\helpers\tree\tree_header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_6895ccefa1d037_67801750',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1eba682c20ca5bbabddc5387de2533a6338c78a9' => 
    array (
      0 => 'C:\\xampp\\htdocs\\qloapps\\admin1\\themes\\default\\template\\helpers\\tree\\tree_header.tpl',
      1 => 1751621738,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6895ccefa1d037_67801750 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="tree-panel-heading-controls clearfix">
	<?php if ((isset($_smarty_tpl->tpl_vars['title']->value))) {?><i class="icon-tag"></i>&nbsp;<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>$_smarty_tpl->tpl_vars['title']->value),$_smarty_tpl ) );
}?>
	<?php if ((isset($_smarty_tpl->tpl_vars['toolbar']->value))) {
echo $_smarty_tpl->tpl_vars['toolbar']->value;
}?>
</div><?php }
}
