<?php
/* Smarty version 4.5.5, created on 2025-08-07 08:28:48
  from 'C:\xampp\htdocs\qloapps\admin\themes\default\template\helpers\list\list.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_689447a082f991_20510498',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '04f2d581395245397fd2ec6e5c8020a5d4abe590' => 
    array (
      0 => 'C:\\xampp\\htdocs\\qloapps\\admin\\themes\\default\\template\\helpers\\list\\list.tpl',
      1 => 1751621738,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_689447a082f991_20510498 (Smarty_Internal_Template $_smarty_tpl) {
echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>


<?php }
}
