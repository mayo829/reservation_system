<?php
/* Smarty version 4.5.5, created on 2025-08-07 02:33:26
  from 'C:\xampp\htdocs\qloapps\admin1\themes\default\template\controllers\login\layout.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_689448b6c8a651_82623153',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0a019c370bfb70e99621fca893f913904ba1b0e2' => 
    array (
      0 => 'C:\\xampp\\htdocs\\qloapps\\admin1\\themes\\default\\template\\controllers\\login\\layout.tpl',
      1 => 1751621738,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_689448b6c8a651_82623153 (Smarty_Internal_Template $_smarty_tpl) {
echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;
}
}
