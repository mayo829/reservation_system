<?php
/* Smarty version 4.5.5, created on 2025-08-07 08:28:47
  from 'C:\xampp\htdocs\qloapps\admin\themes\default\template\controllers\products\helpers\tree\tree_associated_header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_6894479fe92ed4_63016670',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '19f795edac722ca3c7153ec87d14e218278c26c0' => 
    array (
      0 => 'C:\\xampp\\htdocs\\qloapps\\admin\\themes\\default\\template\\controllers\\products\\helpers\\tree\\tree_associated_header.tpl',
      1 => 1751621738,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6894479fe92ed4_63016670 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="tree-panel-heading-controls clearfix"><?php if ((isset($_smarty_tpl->tpl_vars['toolbar']->value))) {
echo $_smarty_tpl->tpl_vars['toolbar']->value;
}?></div>
<?php }
}
