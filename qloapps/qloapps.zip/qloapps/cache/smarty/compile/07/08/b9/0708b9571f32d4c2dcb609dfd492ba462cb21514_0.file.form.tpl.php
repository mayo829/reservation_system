<?php
/* Smarty version 4.5.5, created on 2025-08-08 06:08:17
  from 'C:\xampp\htdocs\qloapps\modules\hotelreservationsystem\views\templates\admin\add_hotel\helpers\form\form.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.5',
  'unifunc' => 'content_6895cc91b04321_72677485',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0708b9571f32d4c2dcb609dfd492ba462cb21514' => 
    array (
      0 => 'C:\\xampp\\htdocs\\qloapps\\modules\\hotelreservationsystem\\views\\templates\\admin\\add_hotel\\helpers\\form\\form.tpl',
      1 => 1751621738,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../../../_partials/htl-form-fields-flag.tpl' => 8,
    'file:../../_partials/htl-images-list.tpl' => 1,
  ),
),false)) {
function content_6895cc91b04321_72677485 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>

<div class="panel">
	<div class="panel-heading">
		<?php if ((isset($_smarty_tpl->tpl_vars['edit']->value))) {?>
			<i class='icon-pencil'></i> <?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Edit Hotel','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

		<?php } else { ?>
			<i class='icon-plus'></i> <?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Add New Hotel','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

		<?php }?>
	</div>

	<form id="<?php echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['table']->value, 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);?>
_form" class="defaultForm <?php echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['name_controller']->value, 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);?>
 form-horizontal" action="<?php echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['current']->value, 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);?>
&<?php if (!empty($_smarty_tpl->tpl_vars['submit_action']->value)) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['submit_action']->value, 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>&token=<?php echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['token']->value, 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);?>
" method="post" enctype="multipart/form-data" <?php if ((isset($_smarty_tpl->tpl_vars['style']->value))) {?>style="<?php echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['style']->value, 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);?>
"<?php }?>>
		<?php if ((isset($_smarty_tpl->tpl_vars['edit']->value))) {?>
			<?php $_smarty_tpl->_assignInScope('hook_arg_id_hotel', $_smarty_tpl->tpl_vars['hotel_info']->value['id']);?>
		<?php } else { ?>
			<?php $_smarty_tpl->_assignInScope('hook_arg_id_hotel', null);?>
		<?php }?>
		<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormTop','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>

		<?php if (count($_smarty_tpl->tpl_vars['languages']->value) > 1) {?>
			<div class="row">
				<div class="col-lg-12">
					<label class="control-label"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Choose Language','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
					<input type="hidden" name="choosedLangId" id="choosedLangId" value="<?php echo $_smarty_tpl->tpl_vars['currentLang']->value['id_lang'];?>
">
					<button type="button" id="multi_lang_btn" class="btn btn-default dropdown-toggle wk_language_toggle" data-toggle="dropdown">
						<?php echo $_smarty_tpl->tpl_vars['currentLang']->value['name'];?>

						<span class="caret"></span>
					</button>
					<ul class="dropdown-menu wk_language_menu" style="left:14%;top:32px;">
						<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['languages']->value, 'language');
$_smarty_tpl->tpl_vars['language']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['language']->value) {
$_smarty_tpl->tpl_vars['language']->do_else = false;
?>
							<li>
								<a href="javascript:void(0)" onclick="showLangField('<?php echo $_smarty_tpl->tpl_vars['language']->value['name'];?>
', <?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
);">
									<?php echo $_smarty_tpl->tpl_vars['language']->value['name'];?>

								</a>
							</li>
						<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
					</ul>
					<p class="help-block"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Change language here to update information in multiple languages.','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</p>
					<hr>
				</div>
			</div>
		<?php }?>
		<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormTabsBefore','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>

		<div class="tabs wk-tabs-panel">
			<ul class="nav nav-tabs">
				<li class="active">
					<a href="#hotel-information" data-toggle="tab">
						<i class="icon-info-sign"></i>
						<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Information','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

					</a>
				</li>
				<li>
					<a href="#hotel-seo" data-toggle="tab">
						<i class="icon-link"></i>
						<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Seo','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

					</a>
				</li>
				<li>
					<a href="#hotel-images" data-toggle="tab">
						<i class="icon-image"></i>
						<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Images','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

					</a>
				</li>
				<li>
					<a href="#hotel-booking-restrictions" data-toggle="tab">
						<i class="icon-lock"></i>
						<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Restrictions','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

					</a>
				</li>
				<li>
					<a href="#hotel-refund-policies" data-toggle="tab">
						<i class="icon-file"></i>
						<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Refund Policies','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

					</a>
				</li>
				<li>
					<a href="#hotel-features" data-toggle="tab">
						<i class="icon-list-alt"></i>
						<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Features','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

					</a>
				</li>
				<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormTab','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>

			</ul>
			<div class="tab-content panel collapse in">
				<div class="tab-pane active" id="hotel-information">
					<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormInformationTabBefore','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>


					<?php if ((isset($_smarty_tpl->tpl_vars['edit']->value))) {?>
						<input id="id-hotel" type="hidden" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['hotel_info']->value['id'], ENT_QUOTES, 'UTF-8', true);?>
" name="id" />
					<?php }?>
					<div class="form-group">
						<label class="control-label col-lg-3">
							<span>
								<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Enable Hotel','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

							</span>
						</label>
						<div class="col-lg-9 ">
							<span class="switch prestashop-switch fixed-width-lg">
								<input type="radio" <?php if ((isset($_smarty_tpl->tpl_vars['edit']->value)) && $_smarty_tpl->tpl_vars['hotel_info']->value['active'] == 1) {?> checked="checked" <?php } else { ?>checked="checked"<?php }?> value="1" id="ENABLE_HOTEL_on" name="ENABLE_HOTEL">
								<label for="ENABLE_HOTEL_on"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Yes','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
								<input <?php if ((isset($_smarty_tpl->tpl_vars['edit']->value)) && $_smarty_tpl->tpl_vars['hotel_info']->value['active'] == 0) {?> checked="checked" <?php }?> type="radio" value="0" id="ENABLE_HOTEL_off" name="ENABLE_HOTEL">
								<label for="ENABLE_HOTEL_off"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'No','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
								<a class="slide-button btn"></a>
							</span>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-3 control-label required" for="hotel_name" >
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Hotel Name :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

							<?php $_smarty_tpl->_subTemplateRender("file:../../../_partials/htl-form-fields-flag.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
						</label>
						<div class="col-lg-6">
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['languages']->value, 'language');
$_smarty_tpl->tpl_vars['language']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['language']->value) {
$_smarty_tpl->tpl_vars['language']->do_else = false;
?>
								<?php $_smarty_tpl->_assignInScope('hotel_name', "hotel_name_".((string)$_smarty_tpl->tpl_vars['language']->value['id_lang']));?>
								<input type="text"
								id="name_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
								name="hotel_name_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
								value="<?php if ((isset($_POST[$_smarty_tpl->tpl_vars['hotel_name']->value]))) {
echo htmlentities(mb_convert_encoding((string)$_POST[$_smarty_tpl->tpl_vars['hotel_name']->value], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
ob_start();
echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];
$_prefixVariable1 = ob_get_clean();
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['hotel_info']->value['hotel_name'][$_prefixVariable1], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>"
								class="form-control wk_text_field_all wk_text_field_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
 copy2friendlyUrl"
								maxlength="128"
								<?php if ($_smarty_tpl->tpl_vars['currentLang']->value['id_lang'] != $_smarty_tpl->tpl_vars['language']->value['id_lang']) {?>style="display:none;"<?php }?> />
							<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-3 control-label">
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Short Description :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

							<?php $_smarty_tpl->_subTemplateRender("file:../../../_partials/htl-form-fields-flag.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>
						</label>
						<div class="col-lg-6">
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['languages']->value, 'language');
$_smarty_tpl->tpl_vars['language']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['language']->value) {
$_smarty_tpl->tpl_vars['language']->do_else = false;
?>
								<?php $_smarty_tpl->_assignInScope('short_desc_name', "short_description_".((string)$_smarty_tpl->tpl_vars['language']->value['id_lang']));?>
								<div id="short_desc_div_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
" class="wk_text_field_all wk_text_field_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
" <?php if ($_smarty_tpl->tpl_vars['currentLang']->value['id_lang'] != $_smarty_tpl->tpl_vars['language']->value['id_lang']) {?>style="display:none;"<?php }?>>
									<textarea
									name="short_description_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
									id="short_description_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
									<?php if ((isset($_smarty_tpl->tpl_vars['PS_SHORT_DESC_LIMIT']->value)) && $_smarty_tpl->tpl_vars['PS_SHORT_DESC_LIMIT']->value) {?> maxlength="<?php echo intval($_smarty_tpl->tpl_vars['PS_SHORT_DESC_LIMIT']->value);?>
"<?php }?>
									cols="2" rows="3"
									class="form-control"><?php if ((isset($_POST[$_smarty_tpl->tpl_vars['short_desc_name']->value]))) {
echo $_POST[$_smarty_tpl->tpl_vars['short_desc_name']->value];
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
ob_start();
echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];
$_prefixVariable2 = ob_get_clean();
echo $_smarty_tpl->tpl_vars['hotel_info']->value['short_description'][$_prefixVariable2];
}?></textarea>
								</div>
							<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-3 control-label">
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Description :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

							<?php $_smarty_tpl->_subTemplateRender("file:../../../_partials/htl-form-fields-flag.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>
						</label>
						<div class="col-lg-6">
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['languages']->value, 'language');
$_smarty_tpl->tpl_vars['language']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['language']->value) {
$_smarty_tpl->tpl_vars['language']->do_else = false;
?>
								<?php $_smarty_tpl->_assignInScope('description', "description_".((string)$_smarty_tpl->tpl_vars['language']->value['id_lang']));?>
								<div id="description_div_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
" class="wk_text_field_all wk_text_field_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
" <?php if ($_smarty_tpl->tpl_vars['currentLang']->value['id_lang'] != $_smarty_tpl->tpl_vars['language']->value['id_lang']) {?>style="display:none;"<?php }?>>
									<textarea
									name="description_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
									id="description_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
									cols="2" rows="3"
									class="wk_tinymce form-control"><?php if ((isset($_POST[$_smarty_tpl->tpl_vars['description']->value]))) {
echo $_POST[$_smarty_tpl->tpl_vars['description']->value];
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
ob_start();
echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];
$_prefixVariable3 = ob_get_clean();
echo $_smarty_tpl->tpl_vars['hotel_info']->value['description'][$_prefixVariable3];
}?></textarea>
								</div>
							<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-3 control-label required"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Phone :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
						<div class="col-sm-6">
							<input type="text" name="phone" id="phone" value="<?php if ((isset($_POST['phone']))) {
echo $_POST['phone'];
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['address_info']->value['phone'], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>"/>
						</div>
					</div>
					<div class="form-group">
						<label class="col-lg-3 control-label required"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Email :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
						<div class="col-sm-6">
							<div class="input-group">
								<span class="input-group-addon">
									<i class="icon-envelope-o"></i>
								</span>
								<input class="reg_sel_input form-control-static" type="text" name="email" id="hotel_email" value="<?php if ((isset($_POST['email']))) {
echo $_POST['email'];
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['hotel_info']->value['email'], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>"/>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-3 control-label required"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Address :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
						<div class="col-sm-6">
							<textarea name="address" rows="4" cols="35" ><?php if ((isset($_POST['address']))) {
echo $_POST['address'];
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['address_info']->value['address1'], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?></textarea>
						</div>
					</div>
					<div class="form-group check_in_div" style="position:relative">
						<label class="col-sm-3 control-label" for="fax"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Fax','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
						<div class="col-sm-6">
							<input autocomplete="off" type="text" class="form-control" id="fax" name="fax" value="<?php if ((isset($_POST['fax']))) {
echo $_POST['fax'];
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['hotel_info']->value['fax'], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>" />
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-3 required" for="hotel_country"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Rating :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
						<div class="col-sm-6">
							<div style="width: 195px;">
								<select class="form-control" name="hotel_rating" id="hotel_rating" value="">
									<option value=""><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'No star','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</option>
									<option value="1" <?php if (((isset($_POST['hotel_rating'])) && $_POST['hotel_rating'] == '1') || (isset($_smarty_tpl->tpl_vars['edit']->value)) && $_smarty_tpl->tpl_vars['hotel_info']->value['rating'] == '1') {?>selected<?php }?>>*</option>
									<option value="2" <?php if (((isset($_POST['hotel_rating'])) && $_POST['hotel_rating'] == '2') || (isset($_smarty_tpl->tpl_vars['edit']->value)) && $_smarty_tpl->tpl_vars['hotel_info']->value['rating'] == '2') {?>selected<?php }?>>**</option>
									<option value="3" <?php if (((isset($_POST['hotel_rating'])) && $_POST['hotel_rating'] == '3') || (isset($_smarty_tpl->tpl_vars['edit']->value)) && $_smarty_tpl->tpl_vars['hotel_info']->value['rating'] == '3') {?>selected<?php }?>>***</option>
									<option value="4" <?php if (((isset($_POST['hotel_rating'])) && $_POST['hotel_rating'] == '4') || (isset($_smarty_tpl->tpl_vars['edit']->value)) && $_smarty_tpl->tpl_vars['hotel_info']->value['rating'] == '4') {?>selected<?php }?>>****</option>
									<option value="5" <?php if (((isset($_POST['hotel_rating'])) && $_POST['hotel_rating'] == '5') || (isset($_smarty_tpl->tpl_vars['edit']->value)) && $_smarty_tpl->tpl_vars['hotel_info']->value['rating'] == '5') {?>selected<?php }?>>*****</option>
								</select>
							</div>
						</div>
					</div>
					<div class="form-group check_in_div" style="position:relative">
						<label class="col-sm-3 control-label required" for="check_in_time">
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Check-in:','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

						</label>
						<div class="col-sm-2">
							<input autocomplete="off" type="text" class="form-control" id="check_in_time" name="check_in" value="<?php if ((isset($_POST['check_in']))) {
echo $_POST['check_in'];
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['hotel_info']->value['check_in'], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>" />
						</div>
					</div>
					<div class="form-group check_out_div" style="position:relative">
						<label class="col-sm-3 control-label required" for="check_out_time">
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Check-out:','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

						</label>
						<div class="col-sm-2">
							<input autocomplete="off" type="text" class="form-control" id="check_out_time" name="check_out" value="<?php if ((isset($_POST['check_out']))) {
echo $_POST['check_out'];
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['hotel_info']->value['check_out'], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>" />
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-3 required" for="hotel_country"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Country :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
						<div class="col-sm-9">
							<div style="width: 195px;">
								<select class="form-control" name="hotel_country" id="hotel_country" value="">
									<option value="0" selected="selected"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Choose your Country','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
 </option>
									<?php if ($_smarty_tpl->tpl_vars['country_var']->value) {?>
										<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['country_var']->value, 'countr');
$_smarty_tpl->tpl_vars['countr']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['countr']->value) {
$_smarty_tpl->tpl_vars['countr']->do_else = false;
?>
											<option value="<?php echo $_smarty_tpl->tpl_vars['countr']->value['id_country'];?>
" <?php if ((isset($_POST['hotel_country'])) && $_POST['hotel_country']) {
if ($_POST['hotel_country'] == $_smarty_tpl->tpl_vars['countr']->value['id_country']) {?>selected<?php }
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value)) && $_smarty_tpl->tpl_vars['address_info']->value['id_country'] == $_smarty_tpl->tpl_vars['countr']->value['id_country']) {?>selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['countr']->value['name'];?>
</option>
										<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
									<?php }?>
								</select>
							</div>
							<div class="help-block"><em>** <?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'If Hotel\'s country is not present in country list then import that country from','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
<a href="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['link']->value->getAdminLink('AdminLocalization'), ENT_QUOTES, 'UTF-8', true);?>
"> <strong><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Localization','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</strong> </a><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'tab.','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</em></div>
						</div>
					</div>
					<div class="form-group hotel_state_dv" <?php if (!$_smarty_tpl->tpl_vars['state_var']->value) {?>style="display:none;"<?php }?>>
						<label class="control-label col-sm-3 required hotel_state_lbl" for="hotel_state" <?php if (!$_smarty_tpl->tpl_vars['state_var']->value) {?>style="display:none;"<?php }?>><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'State :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
						<div class="col-sm-6">
							<div style="width: 195px;">
								<select class="form-control" name="hotel_state" id="hotel_state">
								<?php if (is_array($_smarty_tpl->tpl_vars['state_var']->value) && count($_smarty_tpl->tpl_vars['state_var']->value)) {?>
									<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['state_var']->value, 'state');
$_smarty_tpl->tpl_vars['state']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['state']->value) {
$_smarty_tpl->tpl_vars['state']->do_else = false;
?>
										<option value="<?php echo $_smarty_tpl->tpl_vars['state']->value['id_state'];?>
" <?php if (((isset($_POST['hotel_state'])) && $_POST['hotel_state'] == $_smarty_tpl->tpl_vars['state']->value['id_state']) || ((isset($_smarty_tpl->tpl_vars['edit']->value)) && $_smarty_tpl->tpl_vars['address_info']->value['id_state'] == $_smarty_tpl->tpl_vars['state']->value['id_state'])) {?>selected<?php }?>> <?php echo $_smarty_tpl->tpl_vars['state']->value['name'];?>
</option>
									<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
								<?php }?>
								</select>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-3 required" for="hotel_city"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'City :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
						<div class="col-sm-6">
							<input class="form-control" type="" data-validate="" id="hotel_city" name="hotel_city" value="<?php if ((isset($_POST['hotel_city']))) {
echo $_POST['hotel_city'];
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['address_info']->value['city'], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>" />
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-3 required" for="hotel_postal_code"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Zip Code :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
						<div class="col-sm-6">
							<input class="form-control" type="" data-validate="" id="hotel_postal_code" name="hotel_postal_code" value="<?php if ((isset($_POST['hotel_postal_code']))) {
echo $_POST['hotel_postal_code'];
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['address_info']->value['postcode'], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>" />
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-3 control-label">
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Hotel Policies :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

							<?php $_smarty_tpl->_subTemplateRender("file:../../../_partials/htl-form-fields-flag.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>
						</label>
						<div class="col-lg-6">
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['languages']->value, 'language');
$_smarty_tpl->tpl_vars['language']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['language']->value) {
$_smarty_tpl->tpl_vars['language']->do_else = false;
?>
								<?php $_smarty_tpl->_assignInScope('policies', "policies_".((string)$_smarty_tpl->tpl_vars['language']->value['id_lang']));?>
								<div id="policies_div_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
" class="wk_text_field_all wk_text_field_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
" <?php if ($_smarty_tpl->tpl_vars['currentLang']->value['id_lang'] != $_smarty_tpl->tpl_vars['language']->value['id_lang']) {?>style="display:none;"<?php }?>>
									<textarea
									name="policies_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
									id="policies_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
									cols="2" rows="3"
									class="wk_tinymce form-control"><?php if ((isset($_POST[$_smarty_tpl->tpl_vars['policies']->value]))) {
echo $_POST[$_smarty_tpl->tpl_vars['policies']->value];
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
ob_start();
echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];
$_prefixVariable4 = ob_get_clean();
echo $_smarty_tpl->tpl_vars['hotel_info']->value['policies'][$_prefixVariable4];
}?></textarea>
								</div>
							<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
						</div>
					</div>
					<?php if ((isset($_smarty_tpl->tpl_vars['enabledDisplayMap']->value)) && $_smarty_tpl->tpl_vars['enabledDisplayMap']->value) {?>
						<div class="form-group">
							<label class="col-sm-3 control-label"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Map:','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
							<div class="col-sm-6" id="googleMapContainer">
								<input type="hidden" id="loclatitude" name="loclatitude" value="<?php if ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['hotel_info']->value['latitude'], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>" />
								<input type="hidden" id="loclongitude" name="loclongitude" value="<?php if ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['hotel_info']->value['longitude'], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>" />
								<input type="hidden" id="locformatedAddr" name="locformatedAddr" value="<?php if ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
echo $_smarty_tpl->tpl_vars['hotel_info']->value['map_formated_address'];
}?>" />
								<input type="hidden" id="googleInputField" name="googleInputField" value="<?php if ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
echo $_smarty_tpl->tpl_vars['hotel_info']->value['map_input_text'];
}?>" />
								<div id="pac-input" class="controls" type="text"></div>
								<div id="map"></div>
							</div>
						</div>
					<?php }?>

					<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormInformationTabAfter','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>

				</div>
				<div class="tab-pane" id="hotel-seo">
					<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormSeoTabBefore','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>

					<div class="form-group">
						<label class="col-sm-3 control-label required" for="link_rewrite" >
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Friendly URL :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

							<?php $_smarty_tpl->_subTemplateRender("file:../../../_partials/htl-form-fields-flag.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>
						</label>
						<div class="col-lg-6">
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['languages']->value, 'language');
$_smarty_tpl->tpl_vars['language']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['language']->value) {
$_smarty_tpl->tpl_vars['language']->do_else = false;
?>
								<?php $_smarty_tpl->_assignInScope('link_rewrite', "link_rewrite_".((string)$_smarty_tpl->tpl_vars['language']->value['id_lang']));?>
								<input type="text"
								id="link_rewrite_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
								name="link_rewrite_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
								value="<?php if ((isset($_POST[$_smarty_tpl->tpl_vars['link_rewrite']->value]))) {
echo htmlentities(mb_convert_encoding((string)$_POST[$_smarty_tpl->tpl_vars['link_rewrite']->value], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
ob_start();
echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];
$_prefixVariable5 = ob_get_clean();
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['link_rewrite_info']->value[$_prefixVariable5], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>"
								class="form-control wk_text_field_all wk_text_field_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
								maxlength="128"
								<?php if ($_smarty_tpl->tpl_vars['currentLang']->value['id_lang'] != $_smarty_tpl->tpl_vars['language']->value['id_lang']) {?>style="display:none;"<?php }?> />
							<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
						</div>
						<div class="col-lg-2">
							<button type="button" class="btn btn-default" onmousedown="updateFriendlyURLByName();"><i class="icon-random"></i> <?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Generate'),$_smarty_tpl ) );?>
</button>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-3 control-label" for="meta_title" >
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Meta title:','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

							<?php $_smarty_tpl->_subTemplateRender("file:../../../_partials/htl-form-fields-flag.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>
						</label>
						<div class="col-lg-6">
						<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['languages']->value, 'language');
$_smarty_tpl->tpl_vars['language']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['language']->value) {
$_smarty_tpl->tpl_vars['language']->do_else = false;
?>
							<?php $_smarty_tpl->_assignInScope('meta_title', "meta_title_".((string)$_smarty_tpl->tpl_vars['language']->value['id_lang']));?>
								<input type="text"
								id="meta_title_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
								name="meta_title_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
								value="<?php if ((isset($_POST[$_smarty_tpl->tpl_vars['meta_title']->value]))) {
echo htmlentities(mb_convert_encoding((string)$_POST[$_smarty_tpl->tpl_vars['meta_title']->value], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['meta_title_info']->value[$_smarty_tpl->tpl_vars['language']->value['id_lang']], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>""
								class="form-control wk_text_field_all wk_text_field_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
								maxlength="128"
								<?php if ($_smarty_tpl->tpl_vars['currentLang']->value['id_lang'] != $_smarty_tpl->tpl_vars['language']->value['id_lang']) {?>style="display:none;"<?php }?> />
							<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-3 control-label" for="meta_title" >
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Meta description:','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

							<?php $_smarty_tpl->_subTemplateRender("file:../../../_partials/htl-form-fields-flag.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>
						</label>
						<div class="col-lg-6">
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['languages']->value, 'language');
$_smarty_tpl->tpl_vars['language']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['language']->value) {
$_smarty_tpl->tpl_vars['language']->do_else = false;
?>
								<?php $_smarty_tpl->_assignInScope('meta_description', "meta_description_".((string)$_smarty_tpl->tpl_vars['language']->value['id_lang']));?>
								<input type="text"
								id="meta_description_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
								name="meta_description_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
								value="<?php if ((isset($_POST[$_smarty_tpl->tpl_vars['meta_description']->value]))) {
echo htmlentities(mb_convert_encoding((string)$_POST[$_smarty_tpl->tpl_vars['meta_description']->value], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
ob_start();
echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];
$_prefixVariable6 = ob_get_clean();
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['meta_description_info']->value[$_prefixVariable6], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>"
								class="form-control wk_text_field_all wk_text_field_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
								maxlength="225"
								<?php if ($_smarty_tpl->tpl_vars['currentLang']->value['id_lang'] != $_smarty_tpl->tpl_vars['language']->value['id_lang']) {?>style="display:none;"<?php }?> />
							<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-3 control-label" for="meta_title" >
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Meta keywords:','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

							<?php $_smarty_tpl->_subTemplateRender("file:../../../_partials/htl-form-fields-flag.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
?>
						</label>
						<div class="col-lg-6">
							<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['languages']->value, 'language');
$_smarty_tpl->tpl_vars['language']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['language']->value) {
$_smarty_tpl->tpl_vars['language']->do_else = false;
?>
								<div class="wk_text_field_all wk_text_field_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
" <?php if ($_smarty_tpl->tpl_vars['currentLang']->value['id_lang'] != $_smarty_tpl->tpl_vars['language']->value['id_lang']) {?>style="display:none;"<?php }?> >
									<?php $_smarty_tpl->_assignInScope('meta_keywords', "meta_keywords_".((string)$_smarty_tpl->tpl_vars['language']->value['id_lang']));?>
									<?php echo '<script'; ?>
 type="text/javascript">
										$().ready(function () {
											var input_id = 'meta_keywords_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
';
											$("#"+input_id).tagify({ delimiters: [13,44], addTagPrompt: "<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Add tag','mod'=>'hotelreservationsystem','js'=>1),$_smarty_tpl ) );?>
"});
											$("#htl_branch_info_form").submit( function() {
												$('#'+input_id).val($('#'+input_id).tagify('serialize'));
											});
										});
									<?php echo '</script'; ?>
>
									<input type="text"
									id="meta_keywords_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
									name="meta_keywords_<?php echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];?>
"
									value="<?php if ((isset($_POST[$_smarty_tpl->tpl_vars['meta_keywords']->value]))) {
echo htmlentities(mb_convert_encoding((string)$_POST[$_smarty_tpl->tpl_vars['meta_keywords']->value], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value))) {
ob_start();
echo $_smarty_tpl->tpl_vars['language']->value['id_lang'];
$_prefixVariable7 = ob_get_clean();
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['meta_keywords_info']->value[$_prefixVariable7], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>"
									class="form-control tagify"
									maxlength="225">
								</div>
							<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
						</div>
					</div>
					<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormSeoTabAfter','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>

				</div>
				<div class="tab-pane" id="hotel-images">
					<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormImagesTabBefore','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>


					<?php if ((isset($_smarty_tpl->tpl_vars['hotel_info']->value['id'])) && $_smarty_tpl->tpl_vars['hotel_info']->value['id']) {?>
						<div class="form-group row">
							<label for="hotel_images" class="col-sm-3 control-label padding-top-0">
								<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Upload images','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
&nbsp;:&nbsp;&nbsp;
							</label>
							<div class="col-sm-5">
								<input class="form-control-static" type="file" accept="image/gif, image/jpg, image/jpeg, image/png" id="hotel_images" name="hotel_images[]" multiple>
							</div>
						</div>
						<hr>
												<h4><i class="icon-image"></i> <span><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Hotel Images','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</span></h4>
						<div class="row">
							<div class="col-sm-12">
								<?php $_smarty_tpl->_subTemplateRender("file:../../_partials/htl-images-list.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
							</div>
						</div>
					<?php } else { ?>
						<div class="alert alert-warning">
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Please save hotel information before saving hotel images.','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

						</div>
					<?php }?>

					<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormImagesTabAfter','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>

				</div>
				<div class="tab-pane" id="hotel-booking-restrictions">
					<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormRestrictionsTabBefore','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>


					<?php if ((isset($_smarty_tpl->tpl_vars['hotel_info']->value['id'])) && $_smarty_tpl->tpl_vars['hotel_info']->value['id']) {?>
						<div class="form-group">
							<label class="control-label col-lg-3">
								<span><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Use Global Maximum checkout offset:','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</span>
							</label>
							<div class="col-lg-6">
								<span class="switch prestashop-switch fixed-width-lg">
									<input type="radio" <?php if ((isset($_POST['enable_use_global_max_checkout_offset']))) {?> <?php if ($_POST['enable_use_global_max_checkout_offset']) {?> checked="checked"<?php }?> <?php } elseif ((isset($_smarty_tpl->tpl_vars['edit']->value)) && (isset($_smarty_tpl->tpl_vars['order_restrict_date_info']->value['use_global_max_checkout_offset'])) && $_smarty_tpl->tpl_vars['order_restrict_date_info']->value['use_global_max_checkout_offset']) {?> checked="checked" <?php } elseif ((isset($_smarty_tpl->tpl_vars['order_restrict_date_info']->value)) && !$_smarty_tpl->tpl_vars['order_restrict_date_info']->value) {?> checked="checked" <?php }?> value="1" id="enable_use_global_max_checkout_offset_on" name="enable_use_global_max_checkout_offset">
									<label for="enable_use_global_max_checkout_offset_on"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Yes','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
									<input type="radio" <?php if ((isset($_POST['enable_use_global_max_checkout_offset']))) {?> <?php if (!$_POST['enable_use_global_max_checkout_offset']) {?> checked="checked"<?php }?> <?php } elseif ((isset($_smarty_tpl->tpl_vars['edit']->value)) && (isset($_smarty_tpl->tpl_vars['order_restrict_date_info']->value['use_global_max_checkout_offset'])) && !$_smarty_tpl->tpl_vars['order_restrict_date_info']->value['use_global_max_checkout_offset']) {?> checked="checked" <?php }?> value="0" id="enable_use_global_max_checkout_offset_off" name="enable_use_global_max_checkout_offset">
									<label for="enable_use_global_max_checkout_offset_off"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'No','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
									<a class="slide-button btn"></a>
								</span>
								<div class="help-block"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Global Maximum checkout offset:','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
 <?php echo $_smarty_tpl->tpl_vars['PS_MAX_CHECKOUT_OFFSET']->value;?>
</div>
							</div>
						</div>
						<div class="form-group" <?php if ((isset($_POST['enable_use_global_max_checkout_offset']))) {?> <?php if (!$_POST['enable_use_global_max_checkout_offset']) {?> style="display:block;" <?php } else { ?> style="display:none;" <?php }?> <?php } elseif ((isset($_smarty_tpl->tpl_vars['order_restrict_date_info']->value['use_global_max_checkout_offset'])) && !$_smarty_tpl->tpl_vars['order_restrict_date_info']->value['use_global_max_checkout_offset']) {?> style="display:block;" <?php } else { ?> style="display:none;" <?php }?>>
							<label class="control-label col-sm-3 required" for="max_checkout_offset"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Maximum checkout offset :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
							<div class="col-sm-2">
								<input type="text" class="form-control" id="max_checkout_offset" name="max_checkout_offset" value="<?php if ((isset($_POST['max_checkout_offset']))) {
echo $_POST['max_checkout_offset'];
} elseif ((isset($_smarty_tpl->tpl_vars['order_restrict_date_info']->value['max_checkout_offset']))) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['order_restrict_date_info']->value['max_checkout_offset'], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>" />
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-lg-3">
								<span><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Use Global minimum booking offset :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</span>
							</label>
							<div class="col-lg-6">
								<span class="switch prestashop-switch fixed-width-lg">
									<input type="radio" <?php if ((isset($_POST['enable_use_global_min_booking_offset']))) {?> <?php if ($_POST['enable_use_global_min_booking_offset']) {?> checked="checked" <?php }?> <?php } elseif ((isset($_smarty_tpl->tpl_vars['edit']->value)) && (isset($_smarty_tpl->tpl_vars['order_restrict_date_info']->value['use_global_min_booking_offset'])) && $_smarty_tpl->tpl_vars['order_restrict_date_info']->value['use_global_min_booking_offset']) {?> checked="checked" <?php } elseif ((isset($_smarty_tpl->tpl_vars['order_restrict_date_info']->value)) && !$_smarty_tpl->tpl_vars['order_restrict_date_info']->value) {?> checked="checked" <?php }?> value="1" id="enable_use_global_min_booking_offset_on" name="enable_use_global_min_booking_offset">
									<label for="enable_use_global_min_booking_offset_on"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Yes','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
									<input type="radio" <?php if ((isset($_POST['enable_use_global_min_booking_offset']))) {?> <?php if (!$_POST['enable_use_global_min_booking_offset']) {?> checked="checked" <?php }?> <?php } elseif ((isset($_smarty_tpl->tpl_vars['edit']->value)) && (isset($_smarty_tpl->tpl_vars['order_restrict_date_info']->value['use_global_min_booking_offset'])) && !$_smarty_tpl->tpl_vars['order_restrict_date_info']->value['use_global_min_booking_offset']) {?> checked="checked" <?php }?> value="0" id="enable_use_global_min_booking_offset_off" name="enable_use_global_min_booking_offset">
									<label for="enable_use_global_min_booking_offset_off"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'No','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
									<a class="slide-button btn"></a>
								</span>
								<div class="help-block"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Global minimum booking offset :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
 <?php echo $_smarty_tpl->tpl_vars['PS_MIN_BOOKING_OFFSET']->value;?>
</div>
							</div>
						</div>
						<div class="form-group" <?php if ((isset($_POST['enable_use_global_min_booking_offset']))) {?> <?php if (!$_POST['enable_use_global_min_booking_offset']) {?> style="display:block;" <?php } else { ?> style="display:none;" <?php }?> <?php } elseif ((isset($_smarty_tpl->tpl_vars['edit']->value)) && (isset($_smarty_tpl->tpl_vars['order_restrict_date_info']->value['use_global_min_booking_offset'])) && !$_smarty_tpl->tpl_vars['order_restrict_date_info']->value['use_global_min_booking_offset']) {?> style="display:block;" <?php } else { ?> style="display:none;" <?php }?>>
							<label class="control-label col-sm-3 required" for="min_booking_offset"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Minimum booking offset :','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
							<div class="col-sm-2">
								<input type="text" class="form-control" id="min_booking_offset" name="min_booking_offset" value="<?php if ((isset($_POST['min_booking_offset']))) {
echo htmlspecialchars((string)$_POST['min_booking_offset'], ENT_QUOTES, 'UTF-8', true);
} elseif ((isset($_smarty_tpl->tpl_vars['edit']->value)) && (isset($_smarty_tpl->tpl_vars['order_restrict_date_info']->value['min_booking_offset']))) {
echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['order_restrict_date_info']->value['min_booking_offset'], 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);
}?>" />
							</div>
							<div class="col-lg-9 col-lg-offset-3">
								<div class="help-block"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Set to 0 to disable this feature.','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</div>
							</div>
						</div>
					<?php } else { ?>
						<div class="alert alert-warning">
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Please save the hotel information before saving the hotel booking restrictions.','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

						</div>
					<?php }?>

					<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormRestrictionsTabAfter','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>

				</div>
				<div class="tab-pane" id="hotel-refund-policies">
					<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormRefundPoliciesTabBefore','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>


					<?php if ((isset($_smarty_tpl->tpl_vars['hotel_info']->value['id'])) && $_smarty_tpl->tpl_vars['hotel_info']->value['id']) {?>
						<?php if ((isset($_smarty_tpl->tpl_vars['WK_ORDER_REFUND_ALLOWED']->value)) && !$_smarty_tpl->tpl_vars['WK_ORDER_REFUND_ALLOWED']->value) {?>
							<div class="alert alert-info">
								<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'To enable hotel-wise refunds, activate order refunds in','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
 <a href="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['link']->value->getAdminLink('AdminOrderRefundRules'), ENT_QUOTES, 'UTF-8', true);?>
" target="_blank"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Manage Order Refund Rules','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</a>
							</div>
						<?php }?>
						<div class="form-group">
							<label for="active_refund" class="control-label col-sm-5">
								<span title="" data-toggle="tooltip" class="label-tooltip" data-original-title='<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Enable, if you want to enable refund for this hotel.','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
'><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Enable refund','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</span>
							</label>
							<div class="col-sm-7">
								<span class="switch prestashop-switch fixed-width-lg">
									<input type="radio" value="1" id="active_refund_on" name="active_refund" <?php if ((isset($_smarty_tpl->tpl_vars['WK_ORDER_REFUND_ALLOWED']->value)) && !$_smarty_tpl->tpl_vars['WK_ORDER_REFUND_ALLOWED']->value) {?> disabled="disabled" <?php } elseif ((isset($_POST['active_refund']))) {
if ($_POST['active_refund']) {?>checked="checked"<?php }
} elseif ((isset($_smarty_tpl->tpl_vars['hotel_info']->value)) && $_smarty_tpl->tpl_vars['hotel_info']->value['active_refund']) {?>checked="checked"<?php }?>>
									<label for="active_refund_on"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Yes','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
									<input type="radio" value="0" id="active_refund_off" name="active_refund" <?php if ((isset($_smarty_tpl->tpl_vars['WK_ORDER_REFUND_ALLOWED']->value)) && !$_smarty_tpl->tpl_vars['WK_ORDER_REFUND_ALLOWED']->value) {?> disabled="disabled" checked="checked" <?php } elseif ((isset($_POST['active_refund']))) {
if (!$_POST['active_refund']) {?>checked="checked"<?php }
} elseif (!(isset($_smarty_tpl->tpl_vars['hotel_info']->value))) {?>checked="checked"<?php } elseif ((isset($_smarty_tpl->tpl_vars['hotel_info']->value)) && !$_smarty_tpl->tpl_vars['hotel_info']->value['active_refund']) {?>checked="checked"<?php }?>>
									<label for="active_refund_off"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'No','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</label>
									<a class="slide-button btn"></a>
								</span>
							</div>
						</div>
						<div class="refund_rules_container" <?php if ((isset($_POST['active_refund']))) {
if (!$_POST['active_refund']) {?>style="display:none;"<?php }
} elseif (!(isset($_smarty_tpl->tpl_vars['hotel_info']->value['active_refund'])) || !$_smarty_tpl->tpl_vars['hotel_info']->value['active_refund']) {?>style="display:none;"<?php }?>>
							<?php if ((isset($_smarty_tpl->tpl_vars['allRefundRules']->value)) && $_smarty_tpl->tpl_vars['allRefundRules']->value) {?>
								<hr>
								<div class="table-responsive">
									<table class="table wk-htl-datatable">
										<thead>
											<tr>
												<th></th>
												<th></th>
												<th><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Id','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</th>
												<th><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Name','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</th>
												<th><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Full payment charges','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</th>
												<th><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Advance payment charges','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</th>
												<th><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Days before check-in','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</th>
											</tr>
										</thead>
										<tbody id="slides">
											<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['allRefundRules']->value, 'refundRule');
$_smarty_tpl->tpl_vars['refundRule']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['refundRule']->value) {
$_smarty_tpl->tpl_vars['refundRule']->do_else = false;
?>
												<tr id="slides_<?php echo $_smarty_tpl->tpl_vars['refundRule']->value['id_refund_rule'];?>
">
													<td>
														<i class="icon-arrows "></i>
													</td>
													<td>
														<p class="checkbox">
															<label><input name="htl_refund_rules[]" type="checkbox" class="checkbox" value="<?php echo $_smarty_tpl->tpl_vars['refundRule']->value['id_refund_rule'];?>
" <?php if ((isset($_smarty_tpl->tpl_vars['hotelRefundRules']->value)) && (in_array($_smarty_tpl->tpl_vars['refundRule']->value['id_refund_rule'],$_smarty_tpl->tpl_vars['hotelRefundRules']->value))) {?>checked<?php }?> /></label>
														</p>
													</td>
													<td>
														<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['refundRule']->value['id_refund_rule'], ENT_QUOTES, 'UTF-8', true);?>
 <a target="blank" href="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['link']->value->getAdminLink('AdminOrderRefundRules'), ENT_QUOTES, 'UTF-8', true);?>
&amp;id_refund_rule=<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['refundRule']->value['id_refund_rule'], ENT_QUOTES, 'UTF-8', true);?>
&amp;updatehtl_order_refund_rules"><i class="icon-external-link-sign"></i></a>
													</td>
													<td>
														<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['refundRule']->value['name'], ENT_QUOTES, 'UTF-8', true);?>

													</td>
													<td>
														<?php if ($_smarty_tpl->tpl_vars['refundRule']->value['payment_type'] == $_smarty_tpl->tpl_vars['WK_REFUND_RULE_PAYMENT_TYPE_PERCENTAGE']->value) {?>
															<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['refundRule']->value['deduction_value_full_pay'], ENT_QUOTES, 'UTF-8', true);?>
 %
														<?php } else { ?>
															<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['displayPrice'][0], array( array('price'=>$_smarty_tpl->tpl_vars['refundRule']->value['deduction_value_full_pay'],'currency'=>$_smarty_tpl->tpl_vars['defaultCurrency']->value),$_smarty_tpl ) );?>

														<?php }?>
													</td>
													<td>
														<?php if ($_smarty_tpl->tpl_vars['refundRule']->value['payment_type'] == $_smarty_tpl->tpl_vars['WK_REFUND_RULE_PAYMENT_TYPE_PERCENTAGE']->value) {?>
															<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['refundRule']->value['deduction_value_adv_pay'], ENT_QUOTES, 'UTF-8', true);?>
 %
														<?php } else { ?>
															<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['displayPrice'][0], array( array('price'=>$_smarty_tpl->tpl_vars['refundRule']->value['deduction_value_adv_pay'],'currency'=>$_smarty_tpl->tpl_vars['defaultCurrency']->value),$_smarty_tpl ) );?>

														<?php }?>
													</td>
													<td><?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['refundRule']->value['days'], ENT_QUOTES, 'UTF-8', true);?>
 <?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'days','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</td>
												</tr>
											<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
										</tbody>
									</table>
								</div>
							<?php } else { ?>
								<div class="alert alert-warning">
									<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'No refund rules are created yet.','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
 <?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'You can create refund rules by visiting ','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
 <a target="_blank" href="<?php echo $_smarty_tpl->tpl_vars['link']->value->getAdminLink('AdminOrderRefundRules');?>
"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'create refund rules','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</a>
								</div>
							<?php }?>
						</div>
					<?php } else { ?>
						<div class="alert alert-warning">
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Please save hotel information before saving refund policy options.','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

						</div>
					<?php }?>

					<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormRefundPoliciesTabAfter','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>

				</div>
				<div class="tab-pane" id="hotel-features">
					<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormFeaturesTabBefore','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>

					<?php if ((isset($_smarty_tpl->tpl_vars['hotel_feature_tree']->value))) {?>
						<div class="form-group">
							<label for="hotel_feature" class="control-label col-sm-3">
								<span title="" data-toggle="tooltip" class="label-tooltip" data-original-title='<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Select features for this hotel.','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
'><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Select feature','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</span>
							</label>
							<div class="col-xs-7 hotel_features_tree">
								<?php echo $_smarty_tpl->tpl_vars['hotel_feature_tree']->value;?>

							</div>
						</div>
					<?php } elseif ((isset($_smarty_tpl->tpl_vars['hotel_info']->value['id'])) && $_smarty_tpl->tpl_vars['hotel_info']->value['id']) {?>
						<div class="alert alert-warning">
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'No features created yet.','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
 <?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'You can create features by visiting ','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
 <a target="_blank" href="<?php echo $_smarty_tpl->tpl_vars['link']->value->getAdminLink('AdminHotelFeatures');?>
"><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'manage hotel features.','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>
</a>
						</div>
					<?php } else { ?>
						<div class="alert alert-warning">
							<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Please save hotel information before assigning hotel features.','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

						</div>
					<?php }?>

					<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormFeaturesTabAfter','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>

				</div>
				<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormTabContent','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>

			</div>
		</div>

		<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0], array( array('h'=>'displayAdminAddHotelFormBottom','id_hotel'=>$_smarty_tpl->tpl_vars['hook_arg_id_hotel']->value),$_smarty_tpl ) );?>


		<div class="panel-footer">
			<a href="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['link']->value->getAdminLink('AdminAddHotel'), ENT_QUOTES, 'UTF-8', true);?>
" class="btn btn-default">
				<i class="process-icon-cancel"></i><?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Cancel','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

			</a>
			<button type="submit" name="submitAddhotel_branch_info" class="btn btn-default pull-right">
				<i class="process-icon-save"></i> <?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Save','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

			</button>
			<button type="submit" name="submitAdd<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['table']->value, ENT_QUOTES, 'UTF-8', true);?>
AndStay" class="btn btn-default pull-right">
				<i class="process-icon-save"></i> <?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Save and stay','mod'=>'hotelreservationsystem'),$_smarty_tpl ) );?>

			</button>
		</div>
	</form>
</div>

<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['addJsDef'][0], array( array('adminHotelCtrlUrl'=>$_smarty_tpl->tpl_vars['link']->value->getAdminlink('AdminAddHotel')),$_smarty_tpl ) );
$_block_plugin1 = isset($_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0]) ? $_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0] : null;
if (!is_callable(array($_block_plugin1, 'addJsDefL'))) {
throw new SmartyException('block tag \'addJsDefL\' not callable or registered');
}
$_smarty_tpl->smarty->_cache['_tag_stack'][] = array('addJsDefL', array('name'=>'imgUploadSuccessMsg'));
$_block_repeat=true;
echo $_block_plugin1->addJsDefL(array('name'=>'imgUploadSuccessMsg'), null, $_smarty_tpl, $_block_repeat);
while ($_block_repeat) {
ob_start();
echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Image Successfully Uploaded','js'=>1,'mod'=>'hotelreservationsystem'),$_smarty_tpl ) );
$_block_repeat=false;
echo $_block_plugin1->addJsDefL(array('name'=>'imgUploadSuccessMsg'), ob_get_clean(), $_smarty_tpl, $_block_repeat);
}
array_pop($_smarty_tpl->smarty->_cache['_tag_stack']);
$_block_plugin2 = isset($_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0]) ? $_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0] : null;
if (!is_callable(array($_block_plugin2, 'addJsDefL'))) {
throw new SmartyException('block tag \'addJsDefL\' not callable or registered');
}
$_smarty_tpl->smarty->_cache['_tag_stack'][] = array('addJsDefL', array('name'=>'imgUploadErrorMsg'));
$_block_repeat=true;
echo $_block_plugin2->addJsDefL(array('name'=>'imgUploadErrorMsg'), null, $_smarty_tpl, $_block_repeat);
while ($_block_repeat) {
ob_start();
echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Something went wrong while uploading images. Please try again later !!','js'=>1,'mod'=>'hotelreservationsystem'),$_smarty_tpl ) );
$_block_repeat=false;
echo $_block_plugin2->addJsDefL(array('name'=>'imgUploadErrorMsg'), ob_get_clean(), $_smarty_tpl, $_block_repeat);
}
array_pop($_smarty_tpl->smarty->_cache['_tag_stack']);
$_block_plugin3 = isset($_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0]) ? $_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0] : null;
if (!is_callable(array($_block_plugin3, 'addJsDefL'))) {
throw new SmartyException('block tag \'addJsDefL\' not callable or registered');
}
$_smarty_tpl->smarty->_cache['_tag_stack'][] = array('addJsDefL', array('name'=>'coverImgSuccessMsg'));
$_block_repeat=true;
echo $_block_plugin3->addJsDefL(array('name'=>'coverImgSuccessMsg'), null, $_smarty_tpl, $_block_repeat);
while ($_block_repeat) {
ob_start();
echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Cover image changed successfully','js'=>1,'mod'=>'hotelreservationsystem'),$_smarty_tpl ) );
$_block_repeat=false;
echo $_block_plugin3->addJsDefL(array('name'=>'coverImgSuccessMsg'), ob_get_clean(), $_smarty_tpl, $_block_repeat);
}
array_pop($_smarty_tpl->smarty->_cache['_tag_stack']);
$_block_plugin4 = isset($_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0]) ? $_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0] : null;
if (!is_callable(array($_block_plugin4, 'addJsDefL'))) {
throw new SmartyException('block tag \'addJsDefL\' not callable or registered');
}
$_smarty_tpl->smarty->_cache['_tag_stack'][] = array('addJsDefL', array('name'=>'coverImgErrorMsg'));
$_block_repeat=true;
echo $_block_plugin4->addJsDefL(array('name'=>'coverImgErrorMsg'), null, $_smarty_tpl, $_block_repeat);
while ($_block_repeat) {
ob_start();
echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Error while changing cover image','js'=>1,'mod'=>'hotelreservationsystem'),$_smarty_tpl ) );
$_block_repeat=false;
echo $_block_plugin4->addJsDefL(array('name'=>'coverImgErrorMsg'), ob_get_clean(), $_smarty_tpl, $_block_repeat);
}
array_pop($_smarty_tpl->smarty->_cache['_tag_stack']);
$_block_plugin5 = isset($_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0]) ? $_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0] : null;
if (!is_callable(array($_block_plugin5, 'addJsDefL'))) {
throw new SmartyException('block tag \'addJsDefL\' not callable or registered');
}
$_smarty_tpl->smarty->_cache['_tag_stack'][] = array('addJsDefL', array('name'=>'deleteImgSuccessMsg'));
$_block_repeat=true;
echo $_block_plugin5->addJsDefL(array('name'=>'deleteImgSuccessMsg'), null, $_smarty_tpl, $_block_repeat);
while ($_block_repeat) {
ob_start();
echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Image deleted successfully','js'=>1,'mod'=>'hotelreservationsystem'),$_smarty_tpl ) );
$_block_repeat=false;
echo $_block_plugin5->addJsDefL(array('name'=>'deleteImgSuccessMsg'), ob_get_clean(), $_smarty_tpl, $_block_repeat);
}
array_pop($_smarty_tpl->smarty->_cache['_tag_stack']);
$_block_plugin6 = isset($_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0]) ? $_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0] : null;
if (!is_callable(array($_block_plugin6, 'addJsDefL'))) {
throw new SmartyException('block tag \'addJsDefL\' not callable or registered');
}
$_smarty_tpl->smarty->_cache['_tag_stack'][] = array('addJsDefL', array('name'=>'deleteImgErrorMsg'));
$_block_repeat=true;
echo $_block_plugin6->addJsDefL(array('name'=>'deleteImgErrorMsg'), null, $_smarty_tpl, $_block_repeat);
while ($_block_repeat) {
ob_start();
echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Something went wrong while deleteing image. Please try again later !!','js'=>1,'mod'=>'hotelreservationsystem'),$_smarty_tpl ) );
$_block_repeat=false;
echo $_block_plugin6->addJsDefL(array('name'=>'deleteImgErrorMsg'), ob_get_clean(), $_smarty_tpl, $_block_repeat);
}
array_pop($_smarty_tpl->smarty->_cache['_tag_stack']);
echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['addJsDef'][0], array( array('enabledDisplayMap'=>$_smarty_tpl->tpl_vars['enabledDisplayMap']->value),$_smarty_tpl ) );
echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['addJsDef'][0], array( array('defaultCountry'=>$_smarty_tpl->tpl_vars['defaultCountry']->value),$_smarty_tpl ) );
echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['addJsDef'][0], array( array('statebycountryurl'=>$_smarty_tpl->tpl_vars['link']->value->getAdminLink('AdminAddHotel')),$_smarty_tpl ) );
$_block_plugin7 = isset($_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0]) ? $_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0] : null;
if (!is_callable(array($_block_plugin7, 'addJsDefL'))) {
throw new SmartyException('block tag \'addJsDefL\' not callable or registered');
}
$_smarty_tpl->smarty->_cache['_tag_stack'][] = array('addJsDefL', array('name'=>'htlImgDeleteSuccessMsg'));
$_block_repeat=true;
echo $_block_plugin7->addJsDefL(array('name'=>'htlImgDeleteSuccessMsg'), null, $_smarty_tpl, $_block_repeat);
while ($_block_repeat) {
ob_start();
echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Image removed successfully.','js'=>1,'mod'=>'hotelreservationsystem'),$_smarty_tpl ) );
$_block_repeat=false;
echo $_block_plugin7->addJsDefL(array('name'=>'htlImgDeleteSuccessMsg'), ob_get_clean(), $_smarty_tpl, $_block_repeat);
}
array_pop($_smarty_tpl->smarty->_cache['_tag_stack']);
$_block_plugin8 = isset($_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0]) ? $_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0] : null;
if (!is_callable(array($_block_plugin8, 'addJsDefL'))) {
throw new SmartyException('block tag \'addJsDefL\' not callable or registered');
}
$_smarty_tpl->smarty->_cache['_tag_stack'][] = array('addJsDefL', array('name'=>'htlImgDeleteErrMsg'));
$_block_repeat=true;
echo $_block_plugin8->addJsDefL(array('name'=>'htlImgDeleteErrMsg'), null, $_smarty_tpl, $_block_repeat);
while ($_block_repeat) {
ob_start();
echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['l'][0], array( array('s'=>'Some error occurred while deleting hotel image.','js'=>1,'mod'=>'hotelreservationsystem'),$_smarty_tpl ) );
$_block_repeat=false;
echo $_block_plugin8->addJsDefL(array('name'=>'htlImgDeleteErrMsg'), ob_get_clean(), $_smarty_tpl, $_block_repeat);
}
array_pop($_smarty_tpl->smarty->_cache['_tag_stack']);?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20616426236895cc91aff2e5_10629773', 'script');
?>

<?php }
/* {block "autoload_tinyMCE"} */
class Block_11980358526895cc91b012c5_11731365 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

			tinySetup({
				editor_selector :"wk_tinymce",
				width : 700
			});
		<?php
}
}
/* {/block "autoload_tinyMCE"} */
/* {block 'script'} */
class Block_20616426236895cc91aff2e5_10629773 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_20616426236895cc91aff2e5_10629773',
  ),
  'autoload_tinyMCE' => 
  array (
    0 => 'Block_11980358526895cc91b012c5_11731365',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php echo '<script'; ?>
 type="text/javascript">
	var id_language = <?php echo intval($_smarty_tpl->tpl_vars['defaultFormLanguage']->value);?>
;
	allowEmployeeFormLang = <?php echo intval($_smarty_tpl->tpl_vars['allowEmployeeFormLang']->value);?>
;
	var ps_force_friendly_product = false;

	// for tiny mce setup
	var iso = "<?php echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['iso']->value, 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);?>
";
	var pathCSS = "<?php echo htmlentities(mb_convert_encoding((string)(defined('_THEME_CSS_DIR_') ? constant('_THEME_CSS_DIR_') : null), 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);?>
";
	var ad = "<?php echo htmlentities(mb_convert_encoding((string)$_smarty_tpl->tpl_vars['ad']->value, 'UTF-8', 'UTF-8'), ENT_QUOTES, 'UTF-8', true);?>
";
	$(document).ready(function(){
		<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11980358526895cc91b012c5_11731365', "autoload_tinyMCE", $this->tplIndex);
?>


	});
<?php echo '</script'; ?>
>
<?php
}
}
/* {/block 'script'} */
}
